package org.springComponents;

import org.hiberEntities.User.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Scanner;

@Component("conn")
public class ServConnection{
    @Autowired
    private FactoryControl factoryControl;
    @Autowired
    private AccessControl accessControl;
    @Autowired
    private WorkOnServ work;

    public ServConnection(FactoryControl factoryControl, AccessControl accessControl, WorkOnServ work){
        this.factoryControl=factoryControl;
        this.accessControl=accessControl;
        this.work=work;
        connect();
    }
    private void connect() {
        Scanner input = new Scanner(System.in);
        while (accessControl.getAccessModifier() == -1){
            System.out.println("Enter login and password");
            String name = input.next();
            String password = input.next();
            accessControl.entrance(new User(name, password));
        }
        work.beginWork();
        factoryControl.closeFactory();
    }

}