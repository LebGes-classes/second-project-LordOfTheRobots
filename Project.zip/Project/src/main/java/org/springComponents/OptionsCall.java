package org.springComponents;

import lombok.Setter;
import org.hiberEntities.Annotations.Access;

import org.hiberEntities.Annotations.NamingForUser;
import org.hiberEntities.Annotations.NotNull;
import org.hiberEntities.people.Employee;
import org.hiberEntities.products.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.util.*;

@Component("option")
public class OptionsCall {
    @Autowired
    @Setter
    private TableInteraction inter;
    @Autowired
    @Setter
    private AccessControl access;
    private final Scanner input = new Scanner(System.in);

    @Autowired
    public OptionsCall(AccessControl access) {
        this.access = access;
    }

    public void callOption(Integer option) {
        if (option == 1) {
            option = initCallOption(option);
            while (option > -1) {
                try {
                    outObjects(inter.show(access.getAvailableTables().get(option - 1)));
                    option = -1;
                } catch (Exception e) {
                    System.out.println("Something went wrong try again or enter -1 to exit");
                    option = input.nextInt();
                }
            }
        } else if (option == 2) {
            option = initCallOption(option);
            System.out.println("Input Beginning of Id");
            while (option > -1) {
                try {
                    outObjects(inter.showByBeginningOfID(access.getAvailableTables().get(option - 1), input.next()));
                    option = -1;
                } catch (Exception e) {
                    System.out.println("Something went wrong try again or enter -1 to exit");
                    option = input.nextInt();
                }
            }
        } else if (option == 3) {
            option = initCallOption(option);
            System.out.println("Input Id");
            while (option > -1) {
                try {
                    outObjects(inter.showById(access.getAvailableTables().get(option - 1), input.next()));
                    option = -1;
                } catch (Exception e) {
                    System.out.println("Something went wrong try again or enter -1 to exit");
                    option = input.nextInt();
                }
            }
        } else if (option == 4) {
            option = initCallOption(option);
            System.out.println("Input Id");
            String id = input.next();
            System.out.println("Press 1 to disable or press another key to return ability");
            while (option > -1) {
                try {
                    inter.disableById(access.getAvailableTables().get(option - 1), id, input.next().equals("1"));
                    option = -1;
                } catch (Exception e) {
                    System.out.println("Something went wrong try again or enter -1 to exit");
                    option = input.nextInt();
                }
            }
        } else if (option == 5) {
            option = initCallOption(option);
            System.out.println("Input Id");
            String id = input.next();
            System.out.println("Press 1 to disable or press another key to return ability");
            while (option > -1) {
                try {
                    inter.cascadeDisable(access.getAvailableTables().get(option - 1), id, input.next().equals("1"));
                    option = -1;
                } catch (Exception e) {
                    System.out.println("Something went wrong try again or enter -1 to exit" + e);
                    option = input.nextInt();
                }
            }
        } else if (option == 6) {
            option = initCallOption(option);
            while (option > -1) {
                try {
                    System.out.print("Enter these statements:\t");
                    inter.insertObject(access.getAvailableTables().get(option - 1),
                            showAndTakeFieldsForInsert(access.getAvailableTables().get(option - 1).getDeclaredFields()));
                    option = -1;
                } catch (Exception e) {
                    System.out.println("Something went wrong try another option again or enter -1 to exit " + e);
                    try {
                        option = input.nextInt();
                    } catch (Exception e1) {
                        System.out.println("Какой идиот будет вводить НЕ число когда его попросили?");
                    }
                }
            }
        } else if (option == 7) {
            while (option > -1) {
                try {
                    System.out.println("Enter employee id and enterprise id where transport him");
                    inter.transfer(Employee.class, input.next(), input.next());
                    option = -1;
                } catch (Exception e) {
                    System.out.println("Something went wrong try again or enter -1 to exit" + e);
                    option = input.nextInt();
                }
            }
        } else if (option == 8) {
            while (option > -1) {
                try {
                    System.out.println("Enter product id, id of enterprise where u transport and how many");
                    inter.transport(Product.class, input.next(), input.next(), input.nextInt());
                    option = -1;
                } catch (Exception e) {
                    System.out.println("Something went wrong try again or enter -1 to exit" + e);
                    option = input.nextInt();
                }
            }
        } else if (option == 9) {
            while (option > -1) {
                try {
                    System.out.println("Enter product id and how many you selling");
                    inter.changeQuantity(Product.class, input.next(), -Math.abs(input.nextInt()), true);
                    option = -1;
                } catch (Exception e) {
                    System.out.println("Something went wrong try again or enter -1 to exit");
                    option = input.nextInt();
                }
            }
        } else if (option == 10) {
            while (option > -1) {
                try {
                    System.out.println("Enter product id and how many you returning");
                    inter.changeQuantity(Product.class, input.next(), Math.abs(input.nextInt()), false);
                    option = -1;
                } catch (Exception e) {
                    System.out.println("Something went wrong try again or enter -1 to exit");
                    option = input.nextInt();
                }
            }
        } else if (option == 11) {
            while (option > -1) {
                try {
                    System.out.println("Enter product id and how many you buying");
                    inter.changeQuantity(Product.class, input.next(), -Math.abs(input.nextInt()), true);
                    option = -1;
                } catch (Exception e) {
                    System.out.println("Something went wrong try again or enter -1 to exit" + e);
                    option = input.nextInt();
                }
            }
        } else {
            System.out.println("Access DENIED");
        }
    }

    private Integer initCallOption(Integer option) {
        System.out.println("Choose category");
        showNaming(access.getAvailableTables());
        option = input.nextInt();
        return option;
    }

    private void showNaming(List<Class> list) {
        for (int i = 0; i < access.getAvailableTables().size(); i++) {
            System.out.println(i + 1 + ": " + ((NamingForUser) list.get(i).getAnnotation(NamingForUser.class)).name() + "\t");
        }
        System.out.println();
    }

    private void showFields(Field... list) {
        for (int i = 0; i < list.length; i++) {
            if (isFieldAvailable(list[i])) {
                System.out.print((list[i].getAnnotation(NamingForUser.class)).name() + "\t");
            }
        }
        System.out.println();
    }

    private List<Field> showAndTakeFieldsForInsert(Field... list) {
        List<Field> fields = new ArrayList<>();
        for (int i = 0; i < list.length; i++) {
            if (isFieldAvailable(list[i]) && list[i].isAnnotationPresent(NotNull.class)) {
                System.out.print((list[i].getAnnotation(NamingForUser.class)).name() + "\t");
                fields.add(list[i]);
            }
        }
        System.out.println();
        return fields;
    }

    private void outObjects(List list) throws IllegalAccessException {
        if (!list.isEmpty()) {
            showFields(list.get(0).getClass().getDeclaredFields());
        }
        for (Object x : list) {
            for (Field field : x.getClass().getDeclaredFields()) {
                if (isFieldAvailable(field)) {
                    System.out.print(field.get(x) + "\t");
                }
            }
            System.out.println();
        }
    }

    private boolean isFieldAvailable(Field field) {
        return field.isAnnotationPresent(NamingForUser.class) && field.isAnnotationPresent(Access.class) &&
                field.getAnnotation(Access.class).access() <= access.getAccessModifier();
    }
}
