package org.springComponents;

import lombok.Getter;
import lombok.Setter;
import org.hiberEntities.Annotations.Access;
import org.hiberEntities.Annotations.NamingForUser;
import org.hiberEntities.User.User;
import org.hiberEntities.people.Positions;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import static java.lang.System.exit;

@Service("access")
public class AccessControl {
    @Getter
    private int accessModifier = -1;
    private Positions position;
    @Autowired
    @Setter
    private FactoryControl factoryControl;
    @Getter
    private List<Class> availableTables = new ArrayList<>();
    private ArrayList<Class> classes = ClassGetter.findAllClasses();

    public void entrance(User user) {
        Session session = factoryControl.getFactory().openSession();
        System.out.println(user.getId());
        User userInDb = session.get(User.class, user.getId());
        if (userInDb != null && userInDb.getPassword().equals(user.getPassword())) {
            position = Positions.values()[userInDb.getPosition()];
            setAccessModifier();
        } else {
            System.out.println("Try again");
        }
        session.close();
    }

    private void setAccessModifier() {
        accessModifier = position.ordinal();
        try {
            setAvailableTables();
        } catch (Exception e) {
            System.out.println("There is no such directory");
            exit(-1);
        }
    }

    public void setAvailableTables() {
        for (int i = 0; i < classes.size(); i++) {
            if (classes.get(i).isAnnotationPresent(Access.class) &&
                    classes.get(i).isAnnotationPresent(NamingForUser.class) &&
                    ((Access) classes.get(i).getAnnotation(Access.class)).access() <= getAccessModifier()) {
                availableTables.add(classes.get(i));
            }
        }
    }
}