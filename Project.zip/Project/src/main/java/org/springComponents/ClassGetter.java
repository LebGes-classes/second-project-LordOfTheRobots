package org.springComponents;


import org.reflections.Reflections;
import org.reflections.scanners.SubTypesScanner;

import java.util.ArrayList;

public class ClassGetter {
    public static ArrayList<Class> findAllClasses() {
        Reflections reflections = new Reflections("org.hiberEntities", new SubTypesScanner(false));
        return new ArrayList<>(reflections.getSubTypesOf(Object.class));
    }
}
