package org.springComponents;

import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Scanner;
@Component("work")
public class WorkOnServ {
    private int option;
    private Scanner input = new Scanner(System.in);
    @Autowired
    @Setter
    private OptionsCall optionsCaller;
    private static final String text =
            """
                    0:  Exit
                    1:  Show all
                    2:  Show by first part of id
                    3:  Show exact on id
                    4:  Change disable by Id
                    5:  Cascade change disable by beginning of id
                    6:  Open new place or hire
                    7: Transfer employee
                    8: Transport product
                    9: Return of product
                    10: Sell of product
                    11: Buy product""";
    public void beginWork(){
        System.out.println("Choose option\n" + text);
        option = input.nextInt();
        while (option != 0){
            optionsCaller.callOption(option);
            System.out.println("Press enter");
            input.nextLine();
            input.nextLine();
            System.out.println(text);
            option = input.nextInt();
        }
    }
}