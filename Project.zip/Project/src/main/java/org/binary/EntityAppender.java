package org.binary;

import org.hiberEntities.places.Storage;
import org.hiberEntities.products.Product;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EntityAppender {
    public static void main(String[] args){
//        Storage post = new Storage("02-1001", "67 avenu", 0, false);
//        Configuration conf = new Configuration();
//        conf.addAnnotatedClass(Storage.class);
//        conf.configure( "cfg.xml");
//        SessionFactory factory = conf.buildSessionFactory();
//        Session session = factory.openSession();
//        Transaction trn = session.beginTransaction();
//        session.persist(post);
//        trn.commit();
    }
}
