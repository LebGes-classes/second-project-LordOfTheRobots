package org.binary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"org.springComponents"})
public class Launch {
    public static void main(String[] args) {
        SpringApplication.run(Launch.class, args);
    }
}