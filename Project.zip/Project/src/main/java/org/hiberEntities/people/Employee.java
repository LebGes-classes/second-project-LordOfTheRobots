package org.hiberEntities.people;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;
import org.hiberEntities.Annotations.Access;
import org.hiberEntities.seprclasses.Disableble;
import org.hiberEntities.Annotations.NamingForUser;
import org.hiberEntities.Annotations.NotNull;

@Getter
@Setter
@Entity(name = "Employees")
@Access(access = 4)
@AllArgsConstructor
@NoArgsConstructor
@NamingForUser(name="Employees")
public class Employee implements Disableble {
    @Id
    @NamingForUser(name = "ID")
    @Access(access = 3)
    public String id;
    @NamingForUser(name = "Name")
    @Access(access = 3)
    @Column(name = "Name")
    @NotNull
    public String name;
    @NamingForUser(name = "Position")
    @Access(access = 3)
    @Column(name = "Position")
    @NotNull
    public Positions position;
    @NamingForUser(name = "Age")
    @Access(access = 3)
    @Column(name = "Age")
    @NotNull
    public Integer age;
    @NamingForUser(name = "Disabled")
    @Access(access = 3)
    @Column(name = "Disabled")
    public Boolean disabled = false;

    public void promote(Positions position) {
        this.position = position;
    }

    @Override
    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }
}
