package org.hiberEntities.people;

public enum Positions {
    TechnicalStuff,
    DeliveryMan,
    Cashier,
    WarehouseWorker,
    Administrator,
    Prog;

    @Override
    public String toString() {
        return super.toString();
    }
}
