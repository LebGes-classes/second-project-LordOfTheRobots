package org.hiberEntities.places;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;
import org.hiberEntities.Annotations.Access;
import org.hiberEntities.seprclasses.Disableble;
import org.hiberEntities.Annotations.NamingForUser;
import org.hiberEntities.Annotations.NotNull;
import org.hiberEntities.seprclasses.Profitable;

@Entity(name = "Posts")
@NoArgsConstructor
@AllArgsConstructor
@Access(access = 1)
@NamingForUser(name="Posts")
@Getter
@Setter
public class Post implements Disableble, Profitable {
    @Id
    @Access(access = 1)
    @NamingForUser(name = "Id")
    @Column(name = "ID")
    public String id;
    @NotNull
    @Access(access = 1)
    @NamingForUser(name = "Street")
    @Column(name = "Street")
    public String street;
    @Access(access = 4)
    @NamingForUser(name = "Profitability")
    @Column(name = "Profitability")
    public int profitability;
    @Access(access = 4)
    @NamingForUser(name = "Disabled")
    @Column(name = "Disabled")
    @Setter
    public Boolean disabled = false;

    @Override
    public Boolean getDisabled() {
        return disabled;
    }

    @Override
    public String getName() {
        return street;
    }

    @Override
    public void setName(String name) {
        street = name;
    }

    @Override
    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }

    @Override
    public Integer getProfitability(){
        return profitability;
    }

    @Override
    public void setProfitability(int profit){
        profitability = profit;
    }
}
