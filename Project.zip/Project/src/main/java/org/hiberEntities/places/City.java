package org.hiberEntities.places;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;
import org.hiberEntities.Annotations.Access;
import org.hiberEntities.seprclasses.Disableble;
import org.hiberEntities.Annotations.NamingForUser;
import org.hiberEntities.Annotations.NotNull;

@NoArgsConstructor
@AllArgsConstructor
@Access(access = 1)
@NamingForUser(name="Cities")
@Getter
@Setter
@Entity(name = "Cities")
public class City implements Disableble {
    @Id
    @Access(access = 1)
    @NamingForUser(name = "Id")
    @Column(name = "ID")
    @Setter
    public String id;
    @NotNull
    @Access(access = 1)
    @NamingForUser(name = "Name")
    @Column(name = "name", unique = true)
    public String name;
    @Access(access = 1)
    @NamingForUser(name = "Disabled")
    @Column(name = "Disabled")
    public Boolean disabled = false;

    @Override
    public Boolean getDisabled() {
        return disabled;
    }

    @Override
    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }
}
