package org.hiberEntities.User;

import lombok.*;
import org.hiberEntities.Annotations.Access;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import org.hiberEntities.seprclasses.Disableble;
import org.hiberEntities.Annotations.NamingForUser;
import org.hiberEntities.Annotations.NotNull;

@Entity(name="Users")
@RequiredArgsConstructor
@AllArgsConstructor
@NoArgsConstructor
@Getter
@NamingForUser(name = "Users")
@Access(access = 4)
public class User implements Disableble {
    @Id
    @NotNull
    @NonNull
    @Column(name="Login", unique = true)
    @NamingForUser(name="Login")
    @Access(access = 4)
    @Setter
    public String id;
    @NotNull
    @NonNull
    @Column(name = "Password")
    @Access(access = 5)
    public String password;
    @Column(name="Access")
    @NamingForUser(name="Position")
    @Access(access = 4)
    @Setter
    public Integer position;

    @Override
    public Boolean getDisabled() {
        return false;
    }

    @Override
    public void setDisabled(boolean disabled) {
    }

    @Override
    public String getName() {
        return id;
    }

    @Override
    public void setName(String name) {
        id = name;
    }
}
