package org.hiberEntities.products;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;
import org.hiberEntities.Annotations.Access;
import org.hiberEntities.Annotations.NamingForUser;
import org.hiberEntities.Annotations.NotNull;
import org.hiberEntities.seprclasses.Countable;
import org.hiberEntities.seprclasses.Valuable;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Products")
@Access(access = 2)
@NamingForUser(name = "Products")
public class Product implements Countable, Valuable {
    @Id
    @Access(access = 1)
    @NamingForUser(name = "Id")
    @Column(name = "Id")
    public String id;
    @NotNull
    @Access(access = 1)
    @NamingForUser(name = "Name")
    @Column(name = "Name")
    public String name;
    @NotNull
    @Access(access = 1)
    @NamingForUser(name = "Mature Product")
    @Column(name = "matureProduct")
    public Boolean matureProduct;
    @NotNull
    @Access(access = 1)
    @NamingForUser(name = "corruptible")
    @Column(name = "corruptible")
    public Boolean corruptible;
    @NotNull
    @Access(access = 1)
    @NamingForUser(name = "Quantity")
    @Column(name = "quantity")
    public Integer quantity;
    @Access(access = 1)
    @NamingForUser(name = "Disabled")
    @Column(name = "Disabled")
    public Boolean disable = false;
    @NotNull
    @Access(access = 1)
    @NamingForUser(name = "Price")
    @Column(name = "Price")
    public Integer price;

    @Override
    public Boolean getDisabled() {
        return disable;
    }

    @Override
    public void setDisabled(boolean disabled) {
        disable = disabled;
    }

    @Override
    public Integer getQuantity() {
        return quantity;
    }

    @Override
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public Integer getValue() {
        return price;
    }

    @Override
    public void setValue(int value) {
        price = value;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }
}

