package org.hiberEntities.seprclasses;

public interface Disableble extends Named {
    Boolean getDisabled();
    String getId();
}
