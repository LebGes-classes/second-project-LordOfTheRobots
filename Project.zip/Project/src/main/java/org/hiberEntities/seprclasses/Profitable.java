package org.hiberEntities.seprclasses;

public interface Profitable {
    void setProfitability(int profit);
    Integer getProfitability();
}
