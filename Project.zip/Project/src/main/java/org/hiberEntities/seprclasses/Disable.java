package org.hiberEntities.seprclasses;

public class Disable implements Disableble {
    public boolean disabled;
    public String id;
    public Disable(){}

    @Override
    public Boolean getDisabled() {
        return disabled;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    @Override
    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }

    @Override
    public String getName() {
        return "";
    }

    @Override
    public void setName(String name) {

    }
}
