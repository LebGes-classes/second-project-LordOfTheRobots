package org.hiberEntities.seprclasses;

public interface Named extends WithId {
    String getName();
    void setName(String name);
}
