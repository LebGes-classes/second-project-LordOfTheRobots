package org.hiberEntities.seprclasses;

public interface WithId {
    void setId(String id);
    void setDisabled(boolean disabled);
}
