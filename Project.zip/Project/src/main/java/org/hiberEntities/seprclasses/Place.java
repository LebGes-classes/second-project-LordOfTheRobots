package org.hiberEntities.seprclasses;

public class Place implements Profitable {
    @Override
    public void setProfitability(int profit) {

    }

    @Override
    public Integer getProfitability() {
        return 0;
    }
}
