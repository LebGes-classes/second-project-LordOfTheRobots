package org.binary;

import org.hiberEntities.seprclasses.Countable;

import java.lang.reflect.Field;

public class Copy<T extends Countable> {
    public T copy(T obj1){
        try{
        T obj = (T) obj1.getClass().getConstructor().newInstance();
        for (Field field: obj1.getClass().getFields()){
            field.set(obj, field.get(obj1));
        }
        return obj;}
        catch (Exception e){
            return null;
        }
    }
}
