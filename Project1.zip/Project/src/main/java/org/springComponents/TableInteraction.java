package org.springComponents;

import jakarta.persistence.Entity;
import jakarta.persistence.Query;
import lombok.Setter;
import org.binary.Copy;
import org.hiberEntities.seprclasses.*;
import org.hiberEntities.places.City;
import org.hiberEntities.places.Post;
import org.hiberEntities.places.Storage;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hiberEntities.people.Positions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


@Component("interaction")
public class TableInteraction {
    private final Scanner input = new Scanner(System.in);
    @Autowired
    @Setter
    private FactoryControl factoryControl;
    private Session session;

    public List<Disableble> show(Class clazz){
        List result;
        session = factoryControl.getFactory().openSession();
        String table = getEntityName(clazz);
        result = session.createQuery("SELECT a FROM " + table + " a", clazz).getResultList();
        session.close();
        return result;
    }

    public List<Disableble> showById(Class clazz, String id){
        session = factoryControl.getFactory().openSession();
        List<Disableble> ans = new ArrayList<>();
        ans.add((Disableble) session.get(clazz, id));
        session.close();
        return ans;
    }

    public List<Disableble> showByBeginningOfID(Class clazz, String cityId){
        List result;
        session = factoryControl.getFactory().openSession();
        String table = getEntityName(clazz);
        Query query = session.createQuery("SELECT s FROM " + table + " s WHERE s.id LIKE :id", clazz);
        query.setParameter("id", cityId + "%");
        result = query.getResultList();
        session.close();
        return result;
    }

    public void cascadeDisable(Class clazz, String idLike, boolean turn){
        List<Disableble> objc = showByBeginningOfID(clazz, idLike);
        session = factoryControl.getFactory().openSession();
        for (Disableble obj : objc){
            disableObject(turn, obj);
        }
        session.close();
    }

    public void disableById(Class clazz, String id, boolean turn){
        Disableble obj = showById(clazz, id).get(0);
        session = factoryControl.getFactory().openSession();
        disableObject(turn, obj);
        session.close();
    }

    private void disableObject(boolean turn, Disableble obj){
        obj.setDisabled(turn);
        Transaction trn = session.beginTransaction();
        session.merge(obj);
        trn.commit();
    }

    public void insertObject(Class clazz, List<Field> fields) throws InvocationTargetException, InstantiationException, IllegalAccessException {
        session = factoryControl.getFactory().openSession();
        Disableble obj = new Disable();
        for (Constructor constr : clazz.getConstructors()){
            if(constr.getParameterCount() == 0){
                obj = (Disableble) constr.newInstance();
                break;
            }
        }
        try {
            for (Field field : fields){
                Type type = field.getType();
                if (type.getTypeName().equals("java.lang.Boolean")){
                    field.set(obj, input.nextBoolean());
                } else if (type.getTypeName().equals("java.lang.Integer")) {
                    field.set(obj, input.nextInt());
                } else if (type.getTypeName().equals("java.lang.String")) {
                    field.set(obj, input.next());
                } else if (type.getTypeName().equals("org.hiberEntities.people.Positions")) {
                    field.set(obj, Positions.values()[input.nextInt()]);
                }
            }
        }catch (Exception e){
            System.out.println("Wrong type entered");
        }
        Transaction trn = session.beginTransaction();
        if(clazz.equals(City.class)){
            makeId(clazz, obj, "", false);
        }
        else {
            System.out.println("Enter id of place");
            makeId(clazz, obj, input.next(), true);
        }
        trn.commit();
        session.close();
    }

    public void transfer(Class clazz, String id, String prefix) throws Exception {
        session = factoryControl.getFactory().openSession();
        Disableble obj = (Disableble) session.get(clazz, id);
        Class clazz1 = null;
        if (tableOfEnterprise(prefix).equals("0")){
            clazz1 = Storage.class;
        } else if (tableOfEnterprise(prefix).equals("1")) {
            clazz1 = Post.class;
        } else{
            throw new Exception("Wrong prefix");
        }
        if (exist(clazz1, prefix)){
            Transaction trn = session.beginTransaction();
            remove(obj);
            makeId(clazz, obj, prefix, true);
            trn.commit();
        }
        session.close();
    }

    public void transport(Class clazz, String id, String enterpriseId, int quantityTransport) {
        session = factoryControl.getFactory().openSession();
        Countable obj = (Countable) session.get(clazz, id);
        int quantity = obj.getQuantity();
        if (quantity > quantityTransport){
            Transaction trn = session.beginTransaction();
            if (exist(clazz, obj.getName(), enterpriseId)){
                Countable obj1 = (Countable) getByNameAndEntrpId(clazz, obj.getName(), enterpriseId);
                obj1.setQuantity(obj1.getQuantity() + quantityTransport);
                session.merge(obj1);
            }
            else {
                Countable obj1 = new Copy<Countable>().copy(obj);
                obj1.setQuantity(quantityTransport);
                makeId(clazz, (Disableble) obj1, enterpriseId, true);
            }
            obj.setQuantity(quantity - quantityTransport);
            session.merge(obj);
            trn.commit();
        } else if (quantity == quantityTransport) {
            Transaction trn = session.beginTransaction();
            if (exist(clazz, obj.getName(), enterpriseId)){
                Countable obj1 = (Countable) getByNameAndEntrpId(clazz, obj.getName(), enterpriseId);
                obj1.setQuantity(obj1.getQuantity() + quantityTransport);
                session.merge(obj1);
            }
            else {
                Countable obj1 = new Copy<Countable>().copy(obj);
                obj1.setQuantity(quantityTransport);
                makeId(clazz, (Disableble) obj1, enterpriseId, true);
            }
            obj.setQuantity(0);
            obj.setDisabled(true);
            session.merge(obj);
            trn.commit();
        } else {
            System.out.println("Too many entered to transport not enough product");
        }
        session.close();
    }

    public void changeQuantity(Class clazz, String id, int quantityChange, boolean decreaseProfit){
        session = factoryControl.getFactory().openSession();
        Valuable obj = (Valuable) session.get(clazz, id);
        int quantity = obj.getQuantity();
        Class clazz1 = Profitable.class;
        if (tableOfEnterprise(id).equals("0")){
            clazz1 = Post.class;
        } else if (tableOfEnterprise(id).equals("1")) {
            clazz1 = Storage.class;
        }
        if (obj.getQuantity() > quantityChange){
            obj.setQuantity(quantity - quantityChange);
            Transaction trn = session.beginTransaction();
            session.merge(obj);
            changeProfitability(clazz1, enterpriseId(id), Math.abs(quantityChange), (decreaseProfit ? -1 : 1) * obj.getValue());
            trn.commit();
        } else if (obj.getQuantity() == quantityChange) {
            obj.setQuantity(0);
            obj.setDisabled(true);
            Transaction trn = session.beginTransaction();
            session.merge(obj);
            changeProfitability(clazz1, enterpriseId(id), Math.abs(quantityChange), (decreaseProfit ? -1 : 1) * obj.getValue());
            trn.commit();
        } else{
            System.out.println("Not enough of this type on object");
        }
        session.close();
    }

    private boolean exist(Class clazz, String name, String previousId){
        String table = getEntityName(clazz);
        Query query = session.createQuery("SELECT a FROM " + table + " a WHERE a.name = :name AND a.id LIKE :id");
        query.setParameter("name", name);
        query.setParameter("id", previousId + "%");
        return !query.getResultList().isEmpty();
    }

    private boolean exist(Class clazz, String id){
        String table = getEntityName(clazz);
        Query query = session.createQuery("SELECT a FROM " + table + " a WHERE a.id LIKE :id");
        query.setParameter("id", id + "%");
        return !query.getResultList().isEmpty();
    }

    private Countable getByNameAndEntrpId(Class clazz, String name, String previousId){
        String table = getEntityName(clazz);
        Query query = session.createQuery("SELECT a FROM " + table + " a WHERE a.name = :name AND a.id LIKE :id");
        query.setParameter("name", name);
        query.setParameter("id", previousId + "%");
        return (Countable) query.getSingleResult();
    }

    private void changeProfitability(Class clazz, String id, int howMany, int price){
        Profitable place = (Profitable) session.get(clazz, id);
        place.setProfitability(place.getProfitability() + howMany * price);
        session.merge(place);
    }

    private void remove(Disableble obj){
        session.remove(obj);
    }

    private void makeId(Class clazz, Disableble obj, String prefix, boolean check) {
        boolean have = !check;
        if (check){
            if(prefix.contains("-")){
                have = switch (tableOfEnterprise(prefix)) {
                    case "0" -> session.get(Post.class, prefix) != null;
                    case "1" -> session.get(Storage.class, prefix) != null;
                    default -> have;
                };
            }
            else{
                have = session.get(City.class,prefix) != null;
            }
        }
        prefix += !prefix.isEmpty() ? "-" : "";
        if (clazz == Storage.class){
            prefix += "1";
        } else if (clazz == Post.class) {
            prefix += "0";
        }
        for (int i = 1; have; i++){
            if (session.get(clazz, prefix + Integer.toHexString(i)) == null){
                obj.setId(prefix + Integer.toHexString(i));
                session.persist(obj);
                break;
            }
        }
    }

    private String tableOfEnterprise(String enterpriseId){
        return subStr(enterpriseId, enterpriseId.indexOf("-") + 1, enterpriseId.indexOf("-") + 2);
    }

    private String enterpriseId(String id){
        for(int i = id.length() - 1; i > 0; i--){
            if (id.charAt(i) == '-'){
                return subStr(id, 0 , i);
            }
        }
        return "";
    }

    private String subStr(String str, int j, int i) {
        StringBuilder ans = new StringBuilder();
        while (i > j) {
            ans.append(str.charAt(j));
            j++;
        }
        return ans.toString();
    }

    private String getEntityName(Class clazz){
        Entity entity = (Entity) clazz.getAnnotation(Entity.class);
        return entity.name();
    }
}