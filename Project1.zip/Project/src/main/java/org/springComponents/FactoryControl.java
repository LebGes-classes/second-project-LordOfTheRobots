package org.springComponents;

import lombok.Getter;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import static java.lang.System.exit;

@Component("factory")
public class FactoryControl {
    @Getter
    private SessionFactory factory;
    public FactoryControl(){
        try{
            Configuration conf = new Configuration();
            ArrayList<Class> classes = ClassGetter.findAllClasses();
            for (Class clazz : classes){
                conf.addAnnotatedClass(clazz);
            }
            conf.configure( "cfg.xml");
            factory = conf.buildSessionFactory();
        }
        catch (Exception e){
            System.out.println("Fabric didn't created because of wrong directory " + e);
            exit(-1);
        }
    }

    public void closeFactory(){
        factory.close();
    }
}
