package org.hiberEntities.places;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;
import org.hiberEntities.Annotations.Access;
import org.hiberEntities.Annotations.NotNull;
import org.hiberEntities.seprclasses.Disableble;
import org.hiberEntities.Annotations.NamingForUser;
import org.hiberEntities.seprclasses.Profitable;

@Entity(name = "Storages")
@NoArgsConstructor
@AllArgsConstructor
@Access(access = 1)
@NamingForUser(name="Storages")
@Getter
@Setter
public class Storage implements Disableble, Profitable {
    @NonNull
    @Id
    @Access(access = 1)
    @NamingForUser(name = "Id")
    @Column(name = "ID")
    public String id;
    @NotNull
    @Access(access = 1)
    @NamingForUser(name = "Street")
    @Column(name = "Street")
    public String street;
    @Access(access = 4)
    @NamingForUser(name = "Profitability")
    @Column(name = "Profitability")
    public Integer profitability;
    @Access(access = 4)
    @NamingForUser(name = "Disabled")
    @Column(name = "Disabled")
    @Setter
    public Boolean disabled = false;


    @Override
    public Boolean getDisabled() {
        return disabled;
    }

    @Override
    public String getName() {
        return street;
    }

    @Override
    public void setName(String name) {
        street = name;
    }

    @Override
    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }

    @Override
    public void setProfitability(int profit) {
        profitability = profit;
    }
}


