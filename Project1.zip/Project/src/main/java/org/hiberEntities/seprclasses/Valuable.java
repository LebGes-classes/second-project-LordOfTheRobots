package org.hiberEntities.seprclasses;

public interface Valuable extends Named, Countable {
    Integer getValue();
    void setValue(int value);
}
