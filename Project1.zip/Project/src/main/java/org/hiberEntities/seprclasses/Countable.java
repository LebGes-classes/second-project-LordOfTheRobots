package org.hiberEntities.seprclasses;

public interface Countable extends Named, Disableble {
    Integer getQuantity();
    void setQuantity(int quantity);
}
